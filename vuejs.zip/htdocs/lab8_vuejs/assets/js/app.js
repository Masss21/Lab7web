const { createApp } = Vue;

const apiUrl = 'http://localhost/lab7_php_ci/public';

createApp({
  data() {
    return {
      artikel: [],
      formData: {
        id: null,
        judul: '',
        isi: '',
        status: 0
      },
      showForm: false,
      formTitle: '',
      statusOptions: [
        { text: 'Draft', value: 0 },
        { text: 'Publish', value: 1 }
      ]
    };
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      axios.get(`${apiUrl}/post`)
        .then(response => {
          this.artikel = response.data.artikel;
        })
        .catch(error => console.error(error));
    },
    statusText(status) {
      return status == 1 ? 'Publish' : 'Draft';
    },
    tambah() {
      this.showForm = true;
      this.formTitle = 'Tambah Data';
      this.formData = {
        id: null,
        judul: '',
        isi: '',
        status: 0
      };
    },
    edit(row) {
      this.showForm = true;
      this.formTitle = 'Ubah Data';
      this.formData = { ...row };
    },
    hapus(index, id) {
      if (confirm('Yakin ingin menghapus data ini?')) {
        axios.delete(`${apiUrl}/post/${id}`)
          .then(() => {
            this.artikel.splice(index, 1);
          })
          .catch(error => console.error(error));
      }
    },
    saveData() {
      if (this.formData.id) {
        // update
        axios.put(`${apiUrl}/post/${this.formData.id}`, this.formData)
          .then(() => {
            this.loadData();
          })
          .catch(error => console.error(error));
      } else {
        // create
        axios.post(`${apiUrl}/post`, this.formData)
          .then(() => {
            this.loadData();
          })
          .catch(error => console.error(error));
      }

      this.showForm = false;
    }
  }
}).mount('#app');
